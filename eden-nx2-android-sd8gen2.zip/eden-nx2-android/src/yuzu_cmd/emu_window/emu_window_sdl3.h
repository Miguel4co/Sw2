// SPDX-FileCopyrightText: Copyright 2026 Eden Emulator Project
// SPDX-License-Identifier: GPL-3.0-or-later

// SPDX-FileCopyrightText: 2016 Citra Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

#include <cstdlib>
#include <tuple>
#include <utility>

#include <SDL3/SDL.h>
#include <SDL3/SDL_timer.h>

#include "core/frontend/emu_window.h"
#include "core/frontend/graphics_context.h"

namespace Core {
class System;
}

namespace InputCommon {
class InputSubsystem;
enum class MouseButton;
} // namespace InputCommon

// EDEN_NX2_HIDE_WINDOW=1 (anything but 0) creates the render window hidden and without focus, for unattended
// test runs that must not cover or interrupt the desktop.
inline SDL_WindowFlags Nx2HiddenWindowFlags() {
    const char* hide = std::getenv("EDEN_NX2_HIDE_WINDOW");
    return hide != nullptr && hide[0] != '0' ? SDL_WINDOW_HIDDEN | SDL_WINDOW_NOT_FOCUSABLE
                                                         : SDL_WindowFlags{0};
}

class EmuWindow_SDL3 : public Core::Frontend::EmuWindow {
public:
    explicit EmuWindow_SDL3(InputCommon::InputSubsystem* input_subsystem_, Core::System& system_);
    ~EmuWindow_SDL3();

    /// Whether the window is still open, and a close request hasn't yet been sent
    bool IsOpen() const;

    /// Returns if window is shown (not minimized)
    bool IsShown() const override;

    /// Wait for the next event on the main thread.
    void OnEvent(SDL_Event& event);

    // Sets the window icon from yuzu.bmp
    void SetWindowIcon();

protected:
    /// Called by WaitEvent when a key is pressed or released.
    void OnKeyEvent(int key, u8 state);

    /// Converts a SDL mouse button into MouseInput mouse button
    InputCommon::MouseButton SDLButtonToMouseButton(u32 button) const;

    // Using std::pair<float,float> will invoke HFA miscompilation bug on g++10
    // on newer versions it emits an annoying warning, so just not use an HFA
    // https://stackoverflow.com/questions/77729813/parameter-passing-for-argument-when-c17-is-enabled-changed-to-match-c14
    using FloatPairNonHFA = std::tuple<float, float, char>;
    FloatPairNonHFA MouseToTouchPos(s32 touch_x, s32 touch_y) const;

    /// Called by WaitEvent when a mouse button is pressed or released
    void OnMouseButton(u32 button, u8 state, s32 x, s32 y);

    /// Called by WaitEvent when the mouse moves.
    void OnMouseMotion(s32 x, s32 y);

    /// Called by WaitEvent when a finger starts touching the touchscreen
    void OnFingerDown(float x, float y, std::size_t id);

    /// Called by WaitEvent when a finger moves while touching the touchscreen
    void OnFingerMotion(float x, float y, std::size_t id);

    /// Called by WaitEvent when a finger stops touching the touchscreen
    void OnFingerUp();

    /// Called by WaitEvent when any event that may cause the window to be resized occurs
    void OnResize();

    /// Called when users want to hide the mouse cursor
    void ShowCursor(bool show_cursor);

    /// Called when user passes the fullscreen parameter flag
    void Fullscreen();

    /// Called when a configuration change affects the minimal size of the window
    void OnMinimalClientAreaChangeRequest(std::pair<u32, u32> minimal_size) override;

    /// Periodic changer of titlebar (independent of event loop)
    SDL_TimerID titlebar_timer;

    // Mouse resetter once it
    SDL_TimerID mouse_timer;

    /// Is the window still open?
    bool is_open = true;

    /// Is the window being shown?
    bool is_shown = true;

    /// Internal SDL3 render window
    SDL_Window* render_window{};

    /// Input subsystem to use with this window.
    InputCommon::InputSubsystem* input_subsystem;

    /// yuzu core instance
    Core::System& system;
};

class DummyContext : public Core::Frontend::GraphicsContext {};
