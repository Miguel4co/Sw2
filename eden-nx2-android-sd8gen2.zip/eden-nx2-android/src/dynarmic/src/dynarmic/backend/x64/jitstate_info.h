// SPDX-FileCopyrightText: Copyright 2026 Eden Emulator Project
// SPDX-License-Identifier: GPL-3.0-or-later

/* This file is part of the dynarmic project.
 * Copyright (c) 2016 MerryMage
 * SPDX-License-Identifier: 0BSD
 */

#pragma once

#include <cstddef>

namespace Dynarmic::Backend::X64 {

struct JitStateInfo {
    template<typename JitStateType>
    JitStateInfo(const JitStateType&)
            : offsetof_guest_MXCSR(offsetof(JitStateType, guest_MXCSR))
            , offsetof_asimd_MXCSR(offsetof(JitStateType, asimd_MXCSR))
            , offsetof_rsb_ptr(offsetof(JitStateType, rsb_ptr))
            , rsb_ptr_mask(JitStateType::RSB_PTR_MASK)
            , offsetof_rsb_location_descriptors(offsetof(JitStateType, rsb_location_descriptors))
            , offsetof_rsb_codeptrs(offsetof(JitStateType, rsb_codeptrs))
            , offsetof_cpsr_nzcv(offsetof(JitStateType, cpsr_nzcv))
            , offsetof_fpsr_exc(offsetof(JitStateType, fpsr_exc))
            , offsetof_fpsr_qc(offsetof(JitStateType, fpsr_qc))
            , offsetof_halt_reason(offsetof(JitStateType, halt_reason)) {}

    const size_t offsetof_guest_MXCSR;
    const size_t offsetof_asimd_MXCSR;
    const size_t offsetof_rsb_ptr;
    const size_t rsb_ptr_mask;
    const size_t offsetof_rsb_location_descriptors;
    const size_t offsetof_rsb_codeptrs;
    const size_t offsetof_cpsr_nzcv;
    const size_t offsetof_fpsr_exc;
    const size_t offsetof_fpsr_qc;
    const size_t offsetof_halt_reason;
};

}  // namespace Dynarmic::Backend::X64
